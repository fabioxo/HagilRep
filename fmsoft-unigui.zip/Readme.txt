
    License text for install "FMSoft_uniGUI_Complete_Professional_*.exe"
    BuildRes for create "UniGUICoreX.RES" file
    you can direct use license text for install
    if you alreay installed,and want to change license infomation,can uses BuildRes create "UniGUICoreX.RES" and replace the res file.
